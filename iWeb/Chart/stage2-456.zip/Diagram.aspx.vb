﻿Imports System.IO

<ButtonBarRequired(False), DirtyPageHandling(False), DisableEnterKey(False)>
Public Class Diagram
    Inherits stub_IngenWebPage

    Private SQL As String
    Public ReadOnly Property client_id As Integer
        Get
            Return ctx.session("client_id")
        End Get
    End Property

    Private ReadOnly Property ModelKey As Integer
        Get
            Return CInt(ctx.item("ModelKey"))
        End Get
    End Property

#Region "Backgrounds"

    Public ReadOnly Property BackgroundImages As ListItem()
        Get
            SQL = "select unique_id, content, description, image_repeat
                     From dbo.background
                    where client_id = @p1
                      and background_type = '01'
                    order by client_id desc, description asc"

            Dim dt As DataTable = IawDB.execGetTable(SQL, client_id)
            Dim listItems As New List(Of ListItem)

            For Each row As DataRow In dt.Rows
                Dim listItem As New ListItem()
                listItem.Value = row("unique_id").ToString()
                listItem.Text = row("description").ToString()
                listItem.Attributes("data-imagerepeat") = row("image_repeat").ToString()
                listItem.Attributes("data-content") = row("content").ToString()
                listItems.Add(listItem)
            Next

            Return listItems.ToArray()
        End Get
    End Property

    Public ReadOnly Property Gradients As ListItem()
        Get
            SQL = "SELECT unique_id, content, description, structure
                     FROM dbo.background
                    WHERE client_id = @p1
                      AND background_type = '02'
                    ORDER BY client_id desc, description asc"

            Dim dt As DataTable = IawDB.execGetTable(SQL, client_id)
            Dim listItems As New List(Of ListItem)

            For Each row As DataRow In dt.Rows
                Dim listItem As New ListItem()
                listItem.Value = row("unique_id").ToString()
                listItem.Text = row("description").ToString()
                listItem.Attributes("data-content") = row("content").ToString()
                listItem.Attributes("data-gradient") = row("structure").ToString()
                listItems.Add(listItem)
            Next

            Return listItems.ToArray()
        End Get
    End Property

    Private ReadOnly Property BackgroundTypesDT As DataTable
        Get
            Dim DT As New DataTable
            DT.Columns.Add("ddType")
            DT.Columns.Add("ddText")

            DT.Rows.Add("SolidColour", "Solid Colour")
            If Gradients.Count > 0 Then
                DT.Rows.Add("Gradient", "Gradient")
            End If
            If BackgroundImages.Count > 0 Then
                DT.Rows.Add("Image", "Image")
            End If

            Return DT
        End Get
    End Property

#End Region

    Protected Sub Page_Load(ByVal sender As Object, ByVal e As System.EventArgs) Handles Me.Load
        ' store the key on the session so we don't have to pass it around everywhere
        ctx.session("ModelKey") = ModelKey

        ' store the user's role in the session so we have it available in the out-of-bounds asmx methods
        ctx.session("ChartRole") = ctx.role

        If File.Exists(Server.MapPath("~/Chart/gojs_23.lic")) Then
            Dim v As String = File.ReadAllText(Server.MapPath("~/Chart/gojs_23.lic"))
            hdnGoJsKey.Value = SawUtil.decrypt(v)
        Else
            hdnGoJsKey.Value = ""
        End If

        ' get list of images from the icon folder and add to the label dialog icon radio button list..
        ' the number of icons per colour set determines the numebr of radio items across, so we have to set this here.

        rbLabelIcon.RepeatColumns = 14
        rbLabelIcon.Items.Clear()
        For Each FI As FileInfo In New DirectoryInfo(Server.MapPath("./Icons")).GetFiles()
            rbLabelIcon.Items.Add(New ListItem("<img src='Icons/" + FI.Name + "'/>", "Icons/" + FI.Name))
        Next

        ' for the sizing controls, set the max values from the global max values

        Dim DR As DataRow = IawDB.execGetTable("SELECT JSON_VALUE(attributes,'$.max_node_height') as max_node_height,
                                                       JSON_VALUE(attributes,'$.max_node_width') as max_node_width
                                                  FROM dbo.model_header H
                                                 WHERE model_key = @p1", ModelKey).Rows(0)
        Dim MaxWidth As Integer = CInt(DR.GetValue("max_node_width", 500))
        Dim MaxHeight As Integer = CInt(DR.GetValue("max_node_height", 200))

        sliderNodeBoxWidth.Maximum = MaxWidth
        sliderNodeBoxWidth.Steps = ((MaxWidth - 100) / 10) + 1
        sliderModelBoxWidth.Maximum = MaxWidth
        sliderModelBoxWidth.Steps = ((MaxWidth - 100) / 10) + 1

        sliderNodeBoxHeight.Maximum = MaxHeight
        sliderNodeBoxHeight.Steps = ((MaxHeight - 50) / 10) + 1
        sliderModelBoxHeight.Maximum = MaxHeight
        sliderModelBoxHeight.Steps = ((MaxHeight - 50) / 10) + 1

        ' Now set the available fonts..

        ddlbFont.Items.Clear()

        Dim Opts As New List(Of Opt) From {
                New Opt("Apply", "Apply to this Node", "Apply changes to this Node only"),
                New Opt("ApplyBelow", "Apply to this Node and Below", "Apply changes to this Node and its children"),
                New Opt("CoParents", "CoParents in same Group", "Apply changes to all CoParents in the same Parent Group"),
                New Opt("CoParentsBelow", "CoParents in same Group and Below", "Apply changes to all CoParents in the same Parent Group and its Children"),
                New Opt("Siblings", "My Siblings", "Apply changes to all Sibling nodes of this type"),
                New Opt("SiblingsBelow", "My Siblings and Below", "Apply changes to all Sibling nodes of this type and their children"),
                New Opt("Level", "At this Level", "Apply changes to all nodes of this type at the same level"),
                New Opt("LevelBelow", "At this Level and Below", "Apply changes to all nodes of this type at the same level and their children"),
                New Opt("All", "All Nodes", "Apply changes to all nodes of this type")
            }

        ' have to supply the translated ddlb option 'title' tooltip here as can't translate later in the sequence of events
        ddlbApplyOptions.Items.Clear()
        Dim li As ListItem
        For Each o As Opt In Opts
            li = New ListItem(o.Str, o.Val)
            li.Attributes.Add("title", o.Tool)
            ddlbApplyOptions.Items.Add(li)
        Next

        ' add the translations for the colour controls.

        'If ctx.languageCode <> "GBR" Then
        Dim s As New List(Of String)
        s.Add(AddkeyAttr("colour", "Text Colour"))
        s.Add(AddkeyAttr("bg_colour", "Text Background"))
        s.Add(AddkeyAttr("font", "Font"))
        s.Add(AddkeyAttr("fontSize", "Font Size"))
        s.Add(AddkeyAttr("bold", "Bold"))
        s.Add(AddkeyAttr("boldChar", "B"))
        s.Add(AddkeyAttr("italic", "Italic"))
        s.Add(AddkeyAttr("italicChar", "i"))
        s.Add(AddkeyAttr("underline", "Underline"))
        s.Add(AddkeyAttr("underlineChar", "U"))
        s.Add(AddkeyAttr("left", "Left Justified"))
        s.Add(AddkeyAttr("center", "Centred"))
        s.Add(AddkeyAttr("right", "Right Justified"))

        ctx.javaScriptForHead = "var fieldNamesOverride = { " + String.Join(",", s.ToArray()) + "};"
        'End If

        ' Now set the text for the menus

        menu_add_text.InnerText = SawLang.Translate("Add Note")
        menu_center.InnerText = SawLang.Translate("Centre at top")
        menu_center_root_node.InnerText = SawLang.Translate("Centre at Root Node")
        menu_zoom.InnerText = SawLang.Translate("Zoom to fit")
        menu_modal_setting.InnerText = SawLang.Translate("Settings")
        menu_make_group.InnerText = SawLang.Translate("Add Group")
        menu_node_detail.InnerText = SawLang.Translate("Record Details")
        menu_label_detail.InnerText = SawLang.Translate("Show Note")
        menu_make_vacant.InnerText = SawLang.Translate("Make Vacant")
        menu_assistant_on.InnerText = SawLang.Translate("Assistant")
        menu_assistant_off.InnerText = SawLang.Translate("Assistant")
        menu_node_setting.InnerText = SawLang.Translate("Amend")
        menu_make_parent_group.InnerText = SawLang.Translate("Make Parent Group")
        menu_make_new_parent.InnerText = SawLang.Translate("Make New Parent")
        menu_make_child.InnerText = SawLang.Translate("Make Child")
        menu_move_to_parent_group.InnerText = SawLang.Translate("Move to parent group")
        menu_move_left.InnerText = SawLang.Translate("Move Left")
        menu_move_right.InnerText = SawLang.Translate("Move Right")
        menu_link_settings.InnerText = SawLang.Translate("Amend")

        ' add the background type, gaground images and gradient dropdowns
        SetDDLB(ddlbChartBackgroundType, BackgroundTypesDT, "ddText", "ddType")
        For Each item As ListItem In BackgroundImages
            ddlbChartBackgroundImage.Items.Add(item)
        Next
        For Each item As ListItem In Gradients
            ddlbChartBackgroundGradient.Items.Add(item)
        Next

    End Sub

    Private Sub btnModelBackToList_Click(sender As Object, e As EventArgs) Handles btnModelBackToList.Click
        ctx.redirect("m_chart_list", True)
    End Sub

    Private Function AddkeyAttr(key As String, text As String) As String
        Return String.Format("{0}: ""{1}""", key, ctx.Translate(text))
    End Function

    Class Opt
        Public Val As String
        Public Str As String
        Public Tool As String
        Public Sub New(V As String, S As String, T As String)
            Val = V
            Str = S
            Tool = T
        End Sub
    End Class

End Class


